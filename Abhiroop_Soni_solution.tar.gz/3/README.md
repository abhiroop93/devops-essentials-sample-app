Solution

Most of the solution is based off the Antirez post http://oldblog.antirez.com/post/autocomplete-with-redis.html.
As per the post, a sorted set is created with all intermediate sub-words of the given word so as to make search easier.
A docker-compose file is used (docker-compose is required), which has two services, a persistent redis service (stores data in a folder called redis-data) without password for ease of use and a flask app that runs on port 8080.
The configuration for the flask app is in config.py. I have assumed a development instance of Flask with bundled werkzeug. Also, the base image for the flask app is python slim.

The api has two endpoints:

For adding words into the dictionary:
/add_word/word=<word> 
This endpoint lets us add words into the dictionary and basic responses are there to acknowledge the same, after validation if the word is actually a word.

For searching:
/autocomplete/query=<query> 
This endpoint lets us query the db for the autocomplete results for the given query string, for eg, if query is fo, and foo and foobar have been added as words before using first endpoint, then it should give those results.

Usage

The runnable is run.sh.
For example, ./run.sh

After running run.sh, to actually use the API,
For example, to add 'truth', the endpoint you would need, http://localhost:8080/add_word/word=truth .
For example, to query 'tr', the endpoint you would need, http://localhost:8080/autocomplete/query=tr .