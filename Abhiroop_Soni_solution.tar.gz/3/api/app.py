from flask import Flask
import logging
import config
import json
import redis

app = Flask(__name__)
app.config.from_object('config.DevelopmentConfig')
logging.basicConfig(level=logging.INFO)

r = redis.StrictRedis(
    host = app.config["REDIS_HOST"], 
    port = app.config["REDIS_PORT"], 
    db = app.config["REDIS_DB"],
    charset="utf-8", 
    decode_responses=True)

set_name=app.config["SET_NAME"]
max_words=app.config["MAX_RESULTS"]

@app.route('/add_word/word=<word>')
def add_word(word):    
    stripped = word.strip().lower()
    if not stripped.isalpha():
        return json.dumps({
        "success": False, 
        "message": "Given word {} is not a valid word".format(stripped)
        })
    for i in range(1,len(stripped)):
        prefix = stripped[0:i]
        r.zadd(set_name, {prefix: 0})
    r.zadd(set_name, {"{}*".format(stripped): 0})
    app.logger.info('Added word - {}.'.format(stripped))
    return json.dumps({
        "success": True, 
        "message": "Word {} added successfully".format(stripped)
        })

@app.route('/autocomplete/query=<query>')
def auto_complete(query):
    app.logger.info('Fetching autocomplete results for {}.'.format(query))    
    return json.dumps(fetch_results(r, query.lower(), max_words))

def fetch_results(r, prefix, count):
    results = []
    start = r.zrank(set_name,prefix)
    if start is None:
        return []
    range = r.zrange(set_name,start+1,-1)
    app.logger.debug('Processing words in the range {}.'.format(range))
    if not range or len(range) == 0:
        return []
    for entry in range:      
        if not entry.startswith(prefix):
            break
        elif entry.endswith('*'):
            results.append(entry[0:-1])
    app.logger.debug('Found results: {}.'.format(results))      
    return results


try:
    if __name__ == "__main__": 
        app.run(host='0.0.0.0')    
except Exception as e:
    print("Unable to open port")