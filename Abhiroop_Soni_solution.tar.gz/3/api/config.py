import os

class DevelopmentConfig():
    REDIS_HOST = os.environ.get('REDIS_HOST')
    REDIS_PORT = os.environ.get('REDIS_PORT')
    REDIS_DB = 0
    SET_NAME = "autocomplete"
    MAX_RESULTS = os.environ.get('AUTOCOMPLETE_MAX_RESULTS')
    FLASK_ENV = os.environ.get('FLASK_ENV')
    DEBUG = False