#!/usr/bin/env bash

set -e 

cd api
docker-compose up -d
