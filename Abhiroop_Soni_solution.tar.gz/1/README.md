Solution

The main runnable uses a custom awk script that simply traverses the whole input line by line and at every step, checks if the previous word is the same as the current one, and discards if it is a duplicate word.

I have added another edge-input file in the inputs directory.

Usage

The main runnable (run.awk) needs executable permissions before running.
