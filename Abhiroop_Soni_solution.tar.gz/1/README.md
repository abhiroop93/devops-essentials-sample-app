Solution

The main runnable uses a custom awk script that simply traverses the whole input line by line and at every step, checks if the previous word is the same as the current one, and discards if it is a duplicate word.

I have added another edge-input file in the inputs directory.

Usage

The main runnable (run.awk) needs to be run. Input is taken from stdin.
For example, cat inputs/sample-input | ./run.awk
